import React from "react";
import UsersList from "./UsersList"; // Import UsersList component

const App = () => {
  return (
    <div>
      <h1>Spotify Clone</h1>
      <UsersList />
    </div>
  );
};

export default App;
